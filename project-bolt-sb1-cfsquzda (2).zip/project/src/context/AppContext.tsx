import React, { createContext, useContext, useState, useEffect } from 'react';
import { Trip, CostEntry, Attachment, AdditionalCost, DelayReason, MissedLoad } from '../types';
import { mockTrips, mockCostEntries, mockAttachments } from '../data/mockData';
import { generateTripId, shouldAutoCompleteTrip, getUnresolvedFlagsCount } from '../utils/helpers';
import { realTimeSyncService } from '../services/realTimeSync';

interface AppContextType {
  trips: Trip[];
  addTrip: (trip: Omit<Trip, 'id' | 'costs' | 'status'>) => string;
  updateTrip: (trip: Trip) => void;
  deleteTrip: (id: string) => void;
  getTrip: (id: string) => Trip | undefined;
  
  addCostEntry: (costEntry: Omit<CostEntry, 'id' | 'attachments'>, files?: FileList) => string;
  updateCostEntry: (costEntry: CostEntry) => void;
  deleteCostEntry: (id: string) => void;
  
  addAttachment: (attachment: Omit<Attachment, 'id'>) => string;
  deleteAttachment: (id: string) => void;
  
  // Additional cost management
  addAdditionalCost: (tripId: string, cost: Omit<AdditionalCost, 'id'>, files?: FileList) => string;
  removeAdditionalCost: (tripId: string, costId: string) => void;
  
  // Delay reason management
  addDelayReason: (tripId: string, delay: Omit<DelayReason, 'id'>) => string;
  
  // NEW: Missed load management
  missedLoads: MissedLoad[];
  addMissedLoad: (missedLoad: Omit<MissedLoad, 'id'>) => string;
  updateMissedLoad: (missedLoad: MissedLoad) => void;
  deleteMissedLoad: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [missedLoads, setMissedLoads] = useState<MissedLoad[]>([]);
  
  // Initialize with mock data
  useEffect(() => {
    // Add default fields to existing trips
    const enhancedTrips = mockTrips.map(trip => ({
      ...trip,
      paymentStatus: trip.paymentStatus || 'unpaid' as const,
      additionalCosts: trip.additionalCosts || [],
      delayReasons: trip.delayReasons || [],
      followUpHistory: trip.followUpHistory || []
    }));
    setTrips(enhancedTrips);
    
    // Initialize with some sample missed loads
    setMissedLoads([
      {
        id: 'ML001',
        customerName: 'Shoprite',
        loadRequestDate: '2025-01-10',
        requestedPickupDate: '2025-01-15',
        requestedDeliveryDate: '2025-01-17',
        route: 'Johannesburg to Durban',
        estimatedRevenue: 25000,
        currency: 'ZAR',
        reason: 'no_vehicle',
        reasonDescription: 'All trucks were committed to other loads',
        resolutionStatus: 'lost_opportunity',
        followUpRequired: false,
        competitorWon: true,
        recordedBy: 'Operations Manager',
        recordedAt: '2025-01-10T14:30:00Z',
        impact: 'high'
      },
      {
        id: 'ML002',
        customerName: 'Massmart',
        loadRequestDate: '2025-01-12',
        requestedPickupDate: '2025-01-18',
        requestedDeliveryDate: '2025-01-20',
        route: 'Cape Town to Johannesburg',
        estimatedRevenue: 4200,
        currency: 'USD',
        reason: 'late_response',
        reasonDescription: 'Customer inquiry received after business hours, responded next day but load was already allocated',
        resolutionStatus: 'rescheduled',
        followUpRequired: true,
        competitorWon: false,
        recordedBy: 'Sales Team',
        recordedAt: '2025-01-12T09:15:00Z',
        impact: 'medium'
      },
      {
        id: 'ML003',
        customerName: 'Teralco',
        loadRequestDate: '2025-01-14',
        requestedPickupDate: '2025-01-20',
        requestedDeliveryDate: '2025-01-22',
        route: 'Harare to Beitbridge',
        estimatedRevenue: 18000,
        currency: 'ZAR',
        reason: 'mechanical_issue',
        reasonDescription: 'Fleet 26H breakdown required emergency repairs',
        resolutionStatus: 'pending',
        followUpRequired: true,
        competitorWon: false,
        recordedBy: 'Fleet Manager',
        recordedAt: '2025-01-14T11:45:00Z',
        impact: 'high'
      }
    ]);
  }, []);
  
  const addTrip = (tripData: Omit<Trip, 'id' | 'costs' | 'status'>): string => {
    const newId = generateTripId();
    const newTrip: Trip = {
      ...tripData,
      id: newId,
      costs: [],
      status: 'active',
      paymentStatus: 'unpaid',
      additionalCosts: [],
      delayReasons: [],
      followUpHistory: [],
      clientType: tripData.clientType || 'external'
    };
    
    setTrips(prevTrips => [...prevTrips, newTrip]);
    
    // Broadcast real-time update
    realTimeSyncService.publishTripUpdate(newId, { action: 'created', trip: newTrip });
    
    return newId;
  };
  
  const updateTrip = (updatedTrip: Trip): void => {
    setTrips(prevTrips => 
      prevTrips.map(trip => 
        trip.id === updatedTrip.id ? updatedTrip : trip
      )
    );
    
    // Broadcast real-time update
    realTimeSyncService.publishTripUpdate(updatedTrip.id, { action: 'updated', trip: updatedTrip });
  };
  
  const deleteTrip = (id: string): void => {
    setTrips(prevTrips => prevTrips.filter(trip => trip.id !== id));
    
    // Broadcast real-time update
    realTimeSyncService.publishTripUpdate(id, { action: 'deleted' });
  };
  
  const getTrip = (id: string): Trip | undefined => {
    return trips.find(trip => trip.id === id);
  };
  
  const addCostEntry = (costEntryData: Omit<CostEntry, 'id' | 'attachments'>, files?: FileList): string => {
    const newId = `C${Date.now()}`;
    
    const attachments: Attachment[] = files ? Array.from(files).map((file, index) => ({
      id: `A${Date.now()}-${index}`,
      costEntryId: newId,
      filename: file.name,
      fileUrl: URL.createObjectURL(file),
      fileType: file.type,
      fileSize: file.size,
      uploadedAt: new Date().toISOString(),
      fileData: ''
    })) : [];
    
    const newCostEntry: CostEntry = {
      ...costEntryData,
      id: newId,
      attachments
    };
    
    setTrips(prevTrips => 
      prevTrips.map(trip => {
        if (trip.id === costEntryData.tripId) {
          const updatedTrip = {
            ...trip,
            costs: [...trip.costs, newCostEntry]
          };
          
          if (shouldAutoCompleteTrip(updatedTrip)) {
            const finalTrip = {
              ...updatedTrip,
              status: 'completed' as const,
              completedAt: new Date().toISOString().split('T')[0],
              completedBy: 'System Auto-Complete',
              autoCompletedAt: new Date().toISOString(),
              autoCompletedReason: 'All investigations resolved - trip automatically completed'
            };
            
            // Broadcast real-time update
            realTimeSyncService.publishTripUpdate(trip.id, { action: 'auto_completed', trip: finalTrip });
            
            return finalTrip;
          }
          
          return updatedTrip;
        }
        return trip;
      })
    );
    
    // Broadcast real-time update
    realTimeSyncService.publishCostUpdate(newId, { action: 'created', cost: newCostEntry });
    
    return newId;
  };
  
  const updateCostEntry = (updatedCostEntry: CostEntry): void => {
    setTrips(prevTrips => 
      prevTrips.map(trip => {
        if (trip.id === updatedCostEntry.tripId) {
          const updatedTrip = {
            ...trip,
            costs: trip.costs.map(cost => 
              cost.id === updatedCostEntry.id ? updatedCostEntry : cost
            )
          };
          
          if (trip.status === 'active' && shouldAutoCompleteTrip(updatedTrip)) {
            const finalTrip = {
              ...updatedTrip,
              status: 'completed' as const,
              completedAt: new Date().toISOString().split('T')[0],
              completedBy: 'System Auto-Complete',
              autoCompletedAt: new Date().toISOString(),
              autoCompletedReason: 'All investigations resolved - trip automatically completed'
            };
            
            // Broadcast real-time update
            realTimeSyncService.publishTripUpdate(trip.id, { action: 'auto_completed', trip: finalTrip });
            
            return finalTrip;
          }
          
          return updatedTrip;
        }
        return trip;
      })
    );
    
    // Broadcast real-time update
    realTimeSyncService.publishCostUpdate(updatedCostEntry.id, { action: 'updated', cost: updatedCostEntry });
  };
  
  const deleteCostEntry = (id: string): void => {
    setTrips(prevTrips => 
      prevTrips.map(trip => ({
        ...trip,
        costs: trip.costs.filter(cost => cost.id !== id)
      }))
    );
    
    // Broadcast real-time update
    realTimeSyncService.publishCostUpdate(id, { action: 'deleted' });
  };
  
  const addAttachment = (attachmentData: Omit<Attachment, 'id'>): string => {
    const newId = `A${Date.now()}`;
    const newAttachment: Attachment = {
      ...attachmentData,
      id: newId
    };
    
    setTrips(prevTrips => 
      prevTrips.map(trip => ({
        ...trip,
        costs: trip.costs.map(cost => {
          if (cost.id === attachmentData.costEntryId) {
            return {
              ...cost,
              attachments: [...cost.attachments, newAttachment]
            };
          }
          return cost;
        })
      }))
    );
    
    return newId;
  };
  
  const deleteAttachment = (id: string): void => {
    setTrips(prevTrips => 
      prevTrips.map(trip => ({
        ...trip,
        costs: trip.costs.map(cost => ({
          ...cost,
          attachments: cost.attachments.filter(att => att.id !== id)
        }))
      }))
    );
  };
  
  // Additional cost management
  const addAdditionalCost = (tripId: string, costData: Omit<AdditionalCost, 'id'>, files?: FileList): string => {
    const newId = `AC${Date.now()}`;
    
    const supportingDocuments: Attachment[] = files ? Array.from(files).map((file, index) => ({
      id: `A${Date.now()}-${index}`,
      tripId,
      filename: file.name,
      fileUrl: URL.createObjectURL(file),
      fileType: file.type,
      fileSize: file.size,
      uploadedAt: new Date().toISOString(),
      fileData: ''
    })) : [];
    
    const newAdditionalCost: AdditionalCost = {
      ...costData,
      id: newId,
      supportingDocuments
    };
    
    setTrips(prevTrips => 
      prevTrips.map(trip => {
        if (trip.id === tripId) {
          return {
            ...trip,
            additionalCosts: [...(trip.additionalCosts || []), newAdditionalCost]
          };
        }
        return trip;
      })
    );
    
    return newId;
  };
  
  const removeAdditionalCost = (tripId: string, costId: string): void => {
    setTrips(prevTrips => 
      prevTrips.map(trip => {
        if (trip.id === tripId) {
          return {
            ...trip,
            additionalCosts: (trip.additionalCosts || []).filter(cost => cost.id !== costId)
          };
        }
        return trip;
      })
    );
  };
  
  // Delay reason management
  const addDelayReason = (tripId: string, delayData: Omit<DelayReason, 'id'>): string => {
    const newId = `DR${Date.now()}`;
    
    const newDelayReason: DelayReason = {
      ...delayData,
      id: newId
    };
    
    setTrips(prevTrips => 
      prevTrips.map(trip => {
        if (trip.id === tripId) {
          return {
            ...trip,
            delayReasons: [...(trip.delayReasons || []), newDelayReason]
          };
        }
        return trip;
      })
    );
    
    return newId;
  };
  
  // NEW: Missed load management
  const addMissedLoad = (missedLoadData: Omit<MissedLoad, 'id'>): string => {
    const newId = `ML${Date.now()}`;
    const newMissedLoad: MissedLoad = {
      ...missedLoadData,
      id: newId
    };
    
    setMissedLoads(prevLoads => [...prevLoads, newMissedLoad]);
    
    // Broadcast real-time update
    realTimeSyncService.broadcastEvent({
      id: `missed-load-${newId}-${Date.now()}`,
      type: 'system_update',
      entityId: newId,
      entityType: 'trip',
      action: 'create',
      data: { missedLoad: newMissedLoad },
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      version: 1
    });
    
    return newId;
  };
  
  const updateMissedLoad = (updatedMissedLoad: MissedLoad): void => {
    setMissedLoads(prevLoads => 
      prevLoads.map(load => 
        load.id === updatedMissedLoad.id ? updatedMissedLoad : load
      )
    );
    
    // Broadcast real-time update
    realTimeSyncService.broadcastEvent({
      id: `missed-load-${updatedMissedLoad.id}-${Date.now()}`,
      type: 'system_update',
      entityId: updatedMissedLoad.id,
      entityType: 'trip',
      action: 'update',
      data: { missedLoad: updatedMissedLoad },
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      version: 1
    });
  };
  
  const deleteMissedLoad = (id: string): void => {
    setMissedLoads(prevLoads => prevLoads.filter(load => load.id !== id));
    
    // Broadcast real-time update
    realTimeSyncService.broadcastEvent({
      id: `missed-load-${id}-${Date.now()}`,
      type: 'system_update',
      entityId: id,
      entityType: 'trip',
      action: 'delete',
      data: {},
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      version: 1
    });
  };
  
  const contextValue: AppContextType = {
    trips,
    addTrip,
    updateTrip,
    deleteTrip,
    getTrip,
    addCostEntry,
    updateCostEntry,
    deleteCostEntry,
    addAttachment,
    deleteAttachment,
    addAdditionalCost,
    removeAdditionalCost,
    addDelayReason,
    missedLoads,
    addMissedLoad,
    updateMissedLoad,
    deleteMissedLoad
  };
  
  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};