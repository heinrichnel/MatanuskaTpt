import { Trip, CostEntry, FlaggedCost, Driver, SystemCostRates, InvoiceAging, AGING_THRESHOLDS } from '../types';

// Date formatting
export const formatDate = (date: string | Date): string => {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

export const formatDateTime = (date: string | Date): string => {
  const d = new Date(date);
  return d.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Currency formatting
export const formatCurrency = (amount: number, currency: 'USD' | 'ZAR' = 'ZAR'): string => {
  const symbol = currency === 'USD' ? '$' : 'R';
  return `${symbol}${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

// Trip ID generation
export const generateTripId = (): string => {
  return `T${Date.now()}`;
};

// Cost calculations
export const calculateTotalCosts = (costs: CostEntry[]): number => {
  return costs.reduce((sum, cost) => sum + cost.amount, 0);
};

export const calculateKPIs = (trip: Trip) => {
  const totalRevenue = trip.baseRevenue || 0;
  const totalExpenses = calculateTotalCosts(trip.costs);
  const additionalCostsTotal = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
  const totalCosts = totalExpenses + additionalCostsTotal;
  const netProfit = totalRevenue - totalCosts;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
  const costPerKm = trip.distanceKm && trip.distanceKm > 0 ? totalCosts / trip.distanceKm : 0;
  const currency = trip.revenueCurrency;

  return {
    totalRevenue,
    totalExpenses: totalCosts,
    netProfit,
    profitMargin,
    costPerKm,
    currency
  };
};

// Flag and investigation helpers
export const getFlaggedCostsCount = (costs: CostEntry[]): number => {
  return costs.filter(cost => cost.isFlagged).length;
};

export const getUnresolvedFlagsCount = (costs: CostEntry[]): number => {
  return costs.filter(cost => cost.isFlagged && cost.investigationStatus !== 'resolved').length;
};

export const canCompleteTrip = (trip: Trip): boolean => {
  const unresolvedFlags = getUnresolvedFlagsCount(trip.costs);
  return unresolvedFlags === 0;
};

// Auto-completion logic for trips when all flags are resolved
export const shouldAutoCompleteTrip = (trip: Trip): boolean => {
  if (trip.status !== 'active') return false;
  
  const flaggedCosts = trip.costs.filter(cost => cost.isFlagged);
  if (flaggedCosts.length === 0) return false;
  
  const unresolvedFlags = getUnresolvedFlagsCount(trip.costs);
  return unresolvedFlags === 0;
};

export const getAllFlaggedCosts = (trips: Trip[]): FlaggedCost[] => {
  const flaggedCosts: FlaggedCost[] = [];
  
  trips.forEach(trip => {
    trip.costs.forEach(cost => {
      if (cost.isFlagged) {
        flaggedCosts.push({
          ...cost,
          tripFleetNumber: trip.fleetNumber,
          tripRoute: trip.route,
          tripDriverName: trip.driverName
        });
      }
    });
  });
  
  return flaggedCosts.sort((a, b) => {
    if (a.investigationStatus === 'pending' && b.investigationStatus !== 'pending') return -1;
    if (a.investigationStatus !== 'pending' && b.investigationStatus === 'pending') return 1;
    return new Date(b.flaggedAt || b.date).getTime() - new Date(a.flaggedAt || a.date).getTime();
  });
};

// NEW: Invoice aging calculations
export const calculateInvoiceAging = (trips: Trip[]): InvoiceAging[] => {
  return trips
    .filter(trip => trip.invoiceNumber && trip.invoiceDate && trip.invoiceDueDate)
    .map(trip => {
      const invoiceDate = new Date(trip.invoiceDate!);
      const dueDate = new Date(trip.invoiceDueDate!);
      const today = new Date();
      const agingDays = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
      
      const thresholds = AGING_THRESHOLDS[trip.revenueCurrency];
      let status: 'current' | 'warning' | 'critical' | 'overdue' = 'current';
      
      if (agingDays >= thresholds.overdue.min) {
        status = 'overdue';
      } else if (agingDays >= thresholds.critical.min && agingDays <= thresholds.critical.max) {
        status = 'critical';
      } else if (agingDays >= thresholds.warning.min && agingDays <= thresholds.warning.max) {
        status = 'warning';
      }

      return {
        tripId: trip.id,
        invoiceNumber: trip.invoiceNumber!,
        customerName: trip.clientName,
        invoiceDate: trip.invoiceDate!,
        dueDate: trip.invoiceDueDate!,
        amount: trip.baseRevenue,
        currency: trip.revenueCurrency,
        agingDays,
        status,
        paymentStatus: trip.paymentStatus,
        lastFollowUp: trip.lastFollowUpDate
      };
    });
};

// NEW: Trip compliance calculations
export const calculateTripCompliance = (trip: Trip): number => {
  let complianceScore = 100;
  
  // Check planned vs actual times
  if (trip.plannedArrivalDateTime && trip.actualArrivalDateTime) {
    const planned = new Date(trip.plannedArrivalDateTime);
    const actual = new Date(trip.actualArrivalDateTime);
    const diffHours = Math.abs((actual.getTime() - planned.getTime()) / (1000 * 60 * 60));
    
    if (diffHours > 4) complianceScore -= 20;
    else if (diffHours > 2) complianceScore -= 10;
    else if (diffHours > 1) complianceScore -= 5;
  }
  
  // Check for delays
  if (trip.delayReasons && trip.delayReasons.length > 0) {
    const totalDelayHours = trip.delayReasons.reduce((sum, delay) => sum + delay.delayDuration, 0);
    complianceScore -= Math.min(30, totalDelayHours * 2);
  }
  
  // Check for missing documentation
  const costsWithoutDocs = trip.costs.filter(cost => cost.attachments.length === 0);
  if (costsWithoutDocs.length > 0) {
    complianceScore -= Math.min(20, costsWithoutDocs.length * 5);
  }
  
  return Math.max(0, complianceScore);
};

// Filtering helpers
export const filterTripsByDateRange = (trips: Trip[], startDate?: string, endDate?: string): Trip[] => {
  if (!startDate && !endDate) return trips;
  
  return trips.filter(trip => {
    const tripStart = new Date(trip.startDate);
    const tripEnd = new Date(trip.endDate);
    
    if (startDate && tripStart < new Date(startDate)) return false;
    if (endDate && tripEnd > new Date(endDate)) return false;
    
    return true;
  });
};

export const filterTripsByClient = (trips: Trip[], client: string): Trip[] => {
  if (!client) return trips;
  return trips.filter(trip => trip.clientName === client);
};

export const filterTripsByCurrency = (trips: Trip[], currency: string): Trip[] => {
  if (!currency) return trips;
  return trips.filter(trip => trip.revenueCurrency === currency);
};

export const filterTripsByDriver = (trips: Trip[], driver: string): Trip[] => {
  if (!driver) return trips;
  return trips.filter(trip => trip.driverName === driver);
};

// Fleet KPIs and reporting
export const calculateFleetKPIs = (trips: Trip[]) => {
  const totalTrips = trips.length;
  const activeTrips = trips.filter(t => t.status === 'active').length;
  const completedTrips = trips.filter(t => t.status === 'completed').length;
  
  const totalRevenue = trips.reduce((sum, trip) => sum + (trip.baseRevenue || 0), 0);
  const totalExpenses = trips.reduce((sum, trip) => {
    const tripCosts = calculateTotalCosts(trip.costs);
    const additionalCosts = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
    return sum + tripCosts + additionalCosts;
  }, 0);
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  // Investigation tracking
  const allFlaggedCosts = getAllFlaggedCosts(trips);
  const tripsWithInvestigations = trips.filter(t => 
    t.costs.some(c => c.isFlagged)).length;
  const investigationRate = totalTrips > 0 ? (tripsWithInvestigations / totalTrips) * 100 : 0;

  // Driver performance
  const driverStats = trips.reduce((acc, trip) => {
    if (!acc[trip.driverName]) {
      acc[trip.driverName] = {
        trips: 0,
        investigations: 0,
        flags: 0,
        revenue: 0,
        expenses: 0,
        totalKilometers: 0,
        complianceScore: 0
      };
    }
    acc[trip.driverName].trips++;
    
    const tripFlags = getFlaggedCostsCount(trip.costs);
    const tripInvestigations = trip.costs.filter(c => c.isFlagged).length;
    
    acc[trip.driverName].flags += tripFlags;
    acc[trip.driverName].investigations += tripInvestigations;
    acc[trip.driverName].revenue += trip.baseRevenue || 0;
    
    const tripCosts = calculateTotalCosts(trip.costs);
    const additionalCosts = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
    acc[trip.driverName].expenses += tripCosts + additionalCosts;
    
    if (trip.distanceKm) {
      acc[trip.driverName].totalKilometers += trip.distanceKm;
    }
    
    acc[trip.driverName].complianceScore += calculateTripCompliance(trip);
    
    return acc;
  }, {} as Record<string, any>);

  // Calculate averages
  Object.keys(driverStats).forEach(driver => {
    const stats = driverStats[driver];
    stats.avgComplianceScore = stats.trips > 0 ? stats.complianceScore / stats.trips : 0;
  });

  // Monthly breakdown
  const monthlyData = trips.reduce((acc, trip) => {
    const month = new Date(trip.startDate).toISOString().slice(0, 7);
    if (!acc[month]) {
      acc[month] = {
        trips: 0,
        revenue: 0,
        expenses: 0,
        investigations: 0
      };
    }
    acc[month].trips++;
    acc[month].revenue += trip.baseRevenue || 0;
    
    const tripCosts = calculateTotalCosts(trip.costs);
    const additionalCosts = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
    acc[month].expenses += tripCosts + additionalCosts;
    
    if (trip.costs.some(c => c.isFlagged)) acc[month].investigations++;
    return acc;
  }, {} as Record<string, any>);

  return {
    totalTrips,
    activeTrips,
    completedTrips,
    totalRevenue,
    totalExpenses,
    netProfit,
    profitMargin,
    tripsWithInvestigations,
    investigationRate,
    driverStats,
    monthlyData,
    topDriversByInvestigations: Object.entries(driverStats)
      .sort(([,a], [,b]) => (b as any).investigations - (a as any).investigations),
    topDriversByFlags: Object.entries(driverStats)
      .sort(([,a], [,b]) => (b as any).flags - (a as any).flags)
  };
};

// Currency-specific fleet reporting
export const generateCurrencyFleetReport = (trips: Trip[], currency: 'USD' | 'ZAR') => {
  const currencyTrips = trips.filter(trip => trip.revenueCurrency === currency);
  
  const totalTrips = currencyTrips.length;
  const activeTrips = currencyTrips.filter(t => t.status === 'active').length;
  const completedTrips = currencyTrips.filter(t => t.status === 'completed').length;
  
  const totalRevenue = currencyTrips.reduce((sum, trip) => sum + (trip.baseRevenue || 0), 0);
  const totalExpenses = currencyTrips.reduce((sum, trip) => {
    const tripCosts = calculateTotalCosts(trip.costs);
    const additionalCosts = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
    return sum + tripCosts + additionalCosts;
  }, 0);
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
  
  const avgRevenuePerTrip = totalTrips > 0 ? totalRevenue / totalTrips : 0;
  const avgCostPerTrip = totalTrips > 0 ? totalExpenses / totalTrips : 0;

  // Client type breakdown
  const internalTrips = currencyTrips.filter(t => t.clientType === 'internal');
  const externalTrips = currencyTrips.filter(t => t.clientType === 'external');
  
  const internalRevenue = internalTrips.reduce((sum, trip) => sum + (trip.baseRevenue || 0), 0);
  const internalExpenses = internalTrips.reduce((sum, trip) => {
    const tripCosts = calculateTotalCosts(trip.costs);
    const additionalCosts = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
    return sum + tripCosts + additionalCosts;
  }, 0);
  const internalProfit = internalRevenue - internalExpenses;
  const internalProfitMargin = internalRevenue > 0 ? (internalProfit / internalRevenue) * 100 : 0;
  
  const externalRevenue = externalTrips.reduce((sum, trip) => sum + (trip.baseRevenue || 0), 0);
  const externalExpenses = externalTrips.reduce((sum, trip) => {
    const tripCosts = calculateTotalCosts(trip.costs);
    const additionalCosts = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
    return sum + tripCosts + additionalCosts;
  }, 0);
  const externalProfit = externalRevenue - externalExpenses;
  const externalProfitMargin = externalRevenue > 0 ? (externalProfit / externalRevenue) * 100 : 0;

  // Investigation metrics
  const allFlags = currencyTrips.flatMap(trip => trip.costs.filter(cost => cost.isFlagged));
  const totalFlags = allFlags.length;
  const unresolvedFlags = allFlags.filter(cost => cost.investigationStatus !== 'resolved').length;
  const tripsWithInvestigations = currencyTrips.filter(t => t.costs.some(c => c.isFlagged)).length;
  const investigationRate = totalTrips > 0 ? (tripsWithInvestigations / totalTrips) * 100 : 0;
  const avgFlagsPerTrip = totalTrips > 0 ? totalFlags / totalTrips : 0;
  
  const resolvedFlags = allFlags.filter(cost => cost.investigationStatus === 'resolved');
  const avgResolutionTime = resolvedFlags.length > 0 ? 
    resolvedFlags.reduce((sum, flag) => {
      if (flag.flaggedAt && flag.resolvedAt) {
        const flaggedDate = new Date(flag.flaggedAt);
        const resolvedDate = new Date(flag.resolvedAt);
        return sum + (resolvedDate.getTime() - flaggedDate.getTime()) / (1000 * 60 * 60 * 24);
      }
      return sum + 3;
    }, 0) / resolvedFlags.length : 0;

  // Driver performance for this currency
  const driverStats = currencyTrips.reduce((acc, trip) => {
    if (!acc[trip.driverName]) {
      acc[trip.driverName] = {
        trips: 0,
        revenue: 0,
        expenses: 0,
        flags: 0,
        internalTrips: 0,
        externalTrips: 0
      };
    }
    
    acc[trip.driverName].trips++;
    acc[trip.driverName].revenue += trip.baseRevenue || 0;
    
    const tripCosts = calculateTotalCosts(trip.costs);
    const additionalCosts = trip.additionalCosts?.reduce((sum, cost) => sum + cost.amount, 0) || 0;
    acc[trip.driverName].expenses += tripCosts + additionalCosts;
    
    acc[trip.driverName].flags += getFlaggedCostsCount(trip.costs);
    
    if (trip.clientType === 'internal') {
      acc[trip.driverName].internalTrips++;
    } else {
      acc[trip.driverName].externalTrips++;
    }
    
    return acc;
  }, {} as Record<string, any>);

  return {
    currency,
    totalTrips,
    activeTrips,
    completedTrips,
    totalRevenue,
    totalExpenses,
    netProfit,
    profitMargin,
    avgRevenuePerTrip,
    avgCostPerTrip,
    internalTrips: internalTrips.length,
    externalTrips: externalTrips.length,
    internalRevenue,
    internalProfitMargin,
    externalRevenue,
    externalProfitMargin,
    totalFlags,
    unresolvedFlags,
    tripsWithInvestigations,
    investigationRate,
    avgFlagsPerTrip,
    avgResolutionTime,
    driverStats
  };
};

// Report generation
export const generateReport = (trip: Trip) => {
  const kpis = calculateKPIs(trip);
  
  // Cost breakdown by category
  const costBreakdown = trip.costs.reduce((acc, cost) => {
    const existing = acc.find(item => item.category === cost.category);
    if (existing) {
      existing.total += cost.amount;
      existing.count++;
    } else {
      acc.push({
        category: cost.category,
        total: cost.amount,
        count: 1,
        percentage: 0
      });
    }
    return acc;
  }, [] as Array<{category: string, total: number, count: number, percentage: number}>);

  // Add additional costs to breakdown
  if (trip.additionalCosts) {
    trip.additionalCosts.forEach(cost => {
      const existing = costBreakdown.find(item => item.category === 'Additional Costs');
      if (existing) {
        existing.total += cost.amount;
        existing.count++;
      } else {
        costBreakdown.push({
          category: 'Additional Costs',
          total: cost.amount,
          count: 1,
          percentage: 0
        });
      }
    });
  }

  // Calculate percentages
  costBreakdown.forEach(item => {
    item.percentage = kpis.totalExpenses > 0 ? (item.total / kpis.totalExpenses) * 100 : 0;
  });

  // Sort by total amount
  costBreakdown.sort((a, b) => b.total - a.total);

  return {
    ...kpis,
    costBreakdown,
    totalCosts: kpis.totalExpenses,
    hasAttachments: trip.costs.some(cost => cost.attachments && cost.attachments.length > 0),
    missingReceipts: trip.costs.filter(cost => !cost.attachments || cost.attachments.length === 0),
    flaggedCosts: trip.costs.filter(cost => cost.isFlagged),
    investigationDetails: trip.investigationNotes || null,
    complianceScore: calculateTripCompliance(trip)
  };
};

export const generateFleetReport = (trips: Trip[]) => {
  const fleetKPIs = calculateFleetKPIs(trips);
  return fleetKPIs;
};

// File icon helper
export const getFileIcon = (fileType: string) => {
  if (fileType.includes('pdf')) return 'FileText';
  if (fileType.includes('image')) return 'Image';
  return 'Paperclip';
};

// Enhanced export functions with additional costs and new features
export const downloadTripPDF = async (trip: Trip) => {
  try {
    const report = generateReport(trip);
    const reportWindow = window.open('', '_blank');
    
    if (reportWindow) {
      reportWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Trip Report - Fleet ${trip.fleetNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            .header { border-bottom: 3px solid #2563eb; padding-bottom: 15px; margin-bottom: 25px; }
            .header h1 { color: #1e40af; margin: 0; }
            .section { margin-bottom: 30px; page-break-inside: avoid; }
            .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
            .kpi-card { border: 2px solid #e5e7eb; padding: 15px; border-radius: 8px; text-align: center; background: #f9fafb; }
            .profit { color: #16a34a; font-weight: bold; }
            .loss { color: #dc2626; font-weight: bold; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th, td { border: 1px solid #d1d5db; padding: 10px; text-align: left; }
            th { background-color: #f3f4f6; font-weight: bold; }
            .investigation { background-color: #fef3c7; padding: 15px; border-left: 4px solid #f59e0b; margin: 15px 0; border-radius: 4px; }
            .missing-receipts { background-color: #fee2e2; padding: 15px; border-left: 4px solid #ef4444; margin: 15px 0; border-radius: 4px; }
            .flagged-item { background-color: #fef3c7; padding: 10px; margin: 5px 0; border-radius: 4px; }
            .status-badge { padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: bold; }
            .status-pending { background: #fef3c7; color: #92400e; }
            .status-progress { background: #dbeafe; color: #1e40af; }
            .status-resolved { background: #d1fae5; color: #065f46; }
            .attachment-list { margin: 10px 0; }
            .attachment-item { display: inline-block; background: #e5e7eb; padding: 4px 8px; margin: 2px; border-radius: 4px; font-size: 12px; }
            .no-attachment { color: #dc2626; font-weight: bold; }
            .attachment-available { color: #16a34a; font-weight: bold; }
            @media print { .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Trip Report - Fleet ${trip.fleetNumber}</h1>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
              <div><strong>Driver:</strong> ${trip.driverName}</div>
              <div><strong>Route:</strong> ${trip.route}</div>
              <div><strong>Client:</strong> ${trip.clientName} (${trip.clientType === 'internal' ? 'Internal' : 'External'})</div>
              <div><strong>Period:</strong> ${formatDate(trip.startDate)} - ${formatDate(trip.endDate)}</div>
              <div><strong>Distance:</strong> ${trip.distanceKm ? trip.distanceKm + ' km' : 'N/A'}</div>
              <div><strong>Status:</strong> <span class="status-badge ${trip.status === 'completed' ? 'status-resolved' : 'status-pending'}">${trip.status.toUpperCase()}</span></div>
              <div><strong>Compliance Score:</strong> ${report.complianceScore.toFixed(1)}%</div>
            </div>
            ${trip.description ? `<div style="margin-top: 10px;"><strong>Description:</strong> ${trip.description}</div>` : ''}
            ${trip.autoCompletedAt ? `<div style="margin-top: 10px; background: #d1fae5; padding: 10px; border-radius: 4px;"><strong>Auto-Completed:</strong> ${formatDateTime(trip.autoCompletedAt)} - ${trip.autoCompletedReason}</div>` : ''}
          </div>

          <div class="section">
            <h2>Financial Performance</h2>
            <div class="kpi-grid">
              <div class="kpi-card">
                <h3 style="margin: 0 0 10px 0; color: #374151;">Total Revenue</h3>
                <p style="font-size: 24px; font-weight: bold; color: #16a34a; margin: 0;">
                  ${formatCurrency(report.totalRevenue, report.currency)}
                </p>
                <small style="color: #6b7280;">${report.currency}</small>
              </div>
              <div class="kpi-card">
                <h3 style="margin: 0 0 10px 0; color: #374151;">Total Expenses</h3>
                <p style="font-size: 24px; font-weight: bold; color: #dc2626; margin: 0;">
                  ${formatCurrency(report.totalExpenses, report.currency)}
                </p>
                <small style="color: #6b7280;">${trip.costs.length} cost entries + ${trip.additionalCosts?.length || 0} additional</small>
              </div>
              <div class="kpi-card">
                <h3 style="margin: 0 0 10px 0; color: #374151;">Net Profit/Loss</h3>
                <p style="font-size: 24px; font-weight: bold; margin: 0;" class="${report.netProfit >= 0 ? 'profit' : 'loss'}">
                  ${formatCurrency(report.netProfit, report.currency)}
                </p>
                <small style="color: #6b7280;">${report.profitMargin.toFixed(1)}% margin</small>
              </div>
              ${report.costPerKm > 0 ? `
              <div class="kpi-card">
                <h3 style="margin: 0 0 10px 0; color: #374151;">Cost per KM</h3>
                <p style="font-size: 24px; font-weight: bold; color: #2563eb; margin: 0;">
                  ${formatCurrency(report.costPerKm, report.currency)}
                </p>
                <small style="color: #6b7280;">per kilometer</small>
              </div>
              ` : ''}
            </div>
          </div>

          ${trip.additionalCosts && trip.additionalCosts.length > 0 ? `
          <div class="section">
            <h2>Additional Costs (${trip.additionalCosts.length})</h2>
            <table>
              <thead>
                <tr>
                  <th>Cost Type</th>
                  <th>Amount</th>
                  <th>Currency</th>
                  <th>Notes</th>
                  <th>Documents</th>
                </tr>
              </thead>
              <tbody>
                ${trip.additionalCosts.map(cost => `
                  <tr>
                    <td>${cost.costType}</td>
                    <td>${formatCurrency(cost.amount, cost.currency)}</td>
                    <td>${cost.currency}</td>
                    <td>${cost.notes || '-'}</td>
                    <td>${cost.supportingDocuments.length} file(s)</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          ` : ''}

          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 1000);
            };
          </script>
        </body>
        </html>
      `);
      
      reportWindow.document.close();
    }
  } catch (error) {
    console.error('Error generating PDF report:', error);
    alert('Error generating PDF report. Please try again.');
  }
};

export const downloadTripExcel = async (trip: Trip) => {
  try {
    const report = generateReport(trip);
    
    let csvContent = "data:text/csv;charset=utf-8,";
    
    csvContent += "TRIP REPORT - COMPREHENSIVE EXPORT\n";
    csvContent += `Generated on,${formatDateTime(new Date())}\n`;
    csvContent += "\n";
    
    // Trip Metadata
    csvContent += "TRIP INFORMATION\n";
    csvContent += `Trip ID,${trip.id}\n`;
    csvContent += `Fleet Number,${trip.fleetNumber}\n`;
    csvContent += `Driver,${trip.driverName}\n`;
    csvContent += `Route,${trip.route}\n`;
    csvContent += `Client,${trip.clientName}\n`;
    csvContent += `Client Type,${trip.clientType === 'internal' ? 'Internal' : 'External'}\n`;
    csvContent += `Start Date,${formatDate(trip.startDate)}\n`;
    csvContent += `End Date,${formatDate(trip.endDate)}\n`;
    csvContent += `Distance (km),${trip.distanceKm || 'N/A'}\n`;
    csvContent += `Status,${trip.status.toUpperCase()}\n`;
    csvContent += `Compliance Score,${report.complianceScore.toFixed(1)}%\n`;
    csvContent += `Description,"${trip.description || 'N/A'}"\n`;
    if (trip.autoCompletedAt) {
      csvContent += `Auto-Completed,${formatDateTime(trip.autoCompletedAt)}\n`;
      csvContent += `Auto-Completion Reason,"${trip.autoCompletedReason}"\n`;
    }
    csvContent += "\n";

    // Financial Performance
    csvContent += "FINANCIAL PERFORMANCE\n";
    csvContent += `Currency,${report.currency}\n`;
    csvContent += `Total Revenue,${report.totalRevenue}\n`;
    csvContent += `Total Expenses,${report.totalExpenses}\n`;
    csvContent += `Net Profit/Loss,${report.netProfit}\n`;
    csvContent += `Profit Margin (%),${report.profitMargin.toFixed(2)}\n`;
    csvContent += `Cost per KM,${report.costPerKm.toFixed(2)}\n`;
    csvContent += `Total Cost Entries,${trip.costs.length}\n`;
    csvContent += `Additional Cost Entries,${trip.additionalCosts?.length || 0}\n`;
    csvContent += "\n";

    // Additional Costs
    if (trip.additionalCosts && trip.additionalCosts.length > 0) {
      csvContent += "ADDITIONAL COSTS\n";
      csvContent += `Cost Type,Amount,Currency,Notes,Documents,Added By,Added Date\n`;
      trip.additionalCosts.forEach(cost => {
        csvContent += `"${cost.costType}",${cost.amount},${cost.currency},"${cost.notes || ''}",${cost.supportingDocuments.length},"${cost.addedBy}","${formatDate(cost.addedAt)}"\n`;
      });
      csvContent += "\n";
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `trip-report-${trip.fleetNumber}-${trip.id}-${formatDate(new Date()).replace(/\s/g, '-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    alert('Excel report downloaded successfully! All additional costs and compliance data included.');
  } catch (error) {
    console.error('Error generating Excel report:', error);
    alert('Error generating Excel report. Please try again.');
  }
};

export const downloadFleetReport = async (trips: Trip[]) => {
  try {
    const fleetReport = generateFleetReport(trips);
    
    let csvContent = "data:text/csv;charset=utf-8,";
    
    csvContent += "FLEET PERFORMANCE REPORT - COMPREHENSIVE EXPORT\n";
    csvContent += `Report Generated,${formatDateTime(new Date())}\n`;
    csvContent += `Report Period,${trips.length > 0 ? formatDate(Math.min(...trips.map(t => new Date(t.startDate).getTime()))) : 'N/A'} to ${trips.length > 0 ? formatDate(Math.max(...trips.map(t => new Date(t.endDate).getTime()))) : 'N/A'}\n`;
    csvContent += "\n";
    
    // Fleet Overview
    csvContent += "FLEET OVERVIEW\n";
    csvContent += `Total Trips,${fleetReport.totalTrips}\n`;
    csvContent += `Active Trips,${fleetReport.activeTrips}\n`;
    csvContent += `Completed Trips,${fleetReport.completedTrips}\n`;
    csvContent += `Total Revenue,${fleetReport.totalRevenue}\n`;
    csvContent += `Total Expenses,${fleetReport.totalExpenses}\n`;
    csvContent += `Net Profit/Loss,${fleetReport.netProfit}\n`;
    csvContent += `Profit Margin (%),${fleetReport.profitMargin.toFixed(2)}\n`;
    csvContent += `Trips with Investigations,${fleetReport.tripsWithInvestigations}\n`;
    csvContent += `Investigation Rate (%),${fleetReport.investigationRate.toFixed(2)}\n`;
    csvContent += `Active Drivers,${Object.keys(fleetReport.driverStats).length}\n`;
    csvContent += "\n";

    // Driver Performance with Compliance
    csvContent += "DRIVER PERFORMANCE ANALYSIS\n";
    csvContent += `Driver Name,Total Trips,Revenue,Expenses,Net Profit,Profit Margin (%),Investigations,Flags,Total Kilometers,Avg Compliance Score\n`;
    Object.entries(fleetReport.driverStats).forEach(([driver, stats]: [string, any]) => {
      const netProfit = stats.revenue - stats.expenses;
      const profitMargin = stats.revenue > 0 ? (netProfit / stats.revenue) * 100 : 0;
      
      csvContent += `"${driver}",${stats.trips},${stats.revenue},${stats.expenses},${netProfit},${profitMargin.toFixed(2)},${stats.investigations},${stats.flags},${stats.totalKilometers},${stats.avgComplianceScore?.toFixed(1) || 0}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `fleet-report-comprehensive-${formatDate(new Date()).replace(/\s/g, '-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    alert('Fleet report downloaded successfully! All performance metrics and compliance data included.');
  } catch (error) {
    console.error('Error generating fleet report:', error);
    alert('Error generating fleet report. Please try again.');
  }
};

// Currency-specific fleet report downloads
export const downloadCurrencyFleetReport = async (trips: Trip[], currency: 'USD' | 'ZAR', format: 'excel' | 'pdf' = 'excel') => {
  try {
    const report = generateCurrencyFleetReport(trips, currency);
    
    if (format === 'pdf') {
      const reportWindow = window.open('', '_blank');
      
      if (reportWindow) {
        reportWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>${currency} Fleet Performance Report</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
              .header { border-bottom: 3px solid #2563eb; padding-bottom: 15px; margin-bottom: 25px; }
              .header h1 { color: #1e40af; margin: 0; }
              .section { margin-bottom: 30px; page-break-inside: avoid; }
              .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
              .kpi-card { border: 2px solid #e5e7eb; padding: 15px; border-radius: 8px; text-align: center; background: #f9fafb; }
              table { width: 100%; border-collapse: collapse; margin: 15px 0; }
              th, td { border: 1px solid #d1d5db; padding: 10px; text-align: left; }
              th { background-color: #f3f4f6; font-weight: bold; }
              @media print { .no-print { display: none; } }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>${currency} Fleet Performance Report</h1>
              <p>Generated on ${formatDateTime(new Date())}</p>
              <p>Currency: ${currency} | Total Trips: ${report.totalTrips}</p>
            </div>

            <div class="section">
              <h2>Fleet Summary</h2>
              <div class="kpi-grid">
                <div class="kpi-card">
                  <h3>Total Revenue</h3>
                  <p style="font-size: 24px; font-weight: bold; color: #16a34a;">
                    ${formatCurrency(report.totalRevenue, currency)}
                  </p>
                </div>
                <div class="kpi-card">
                  <h3>Total Expenses</h3>
                  <p style="font-size: 24px; font-weight: bold; color: #dc2626;">
                    ${formatCurrency(report.totalExpenses, currency)}
                  </p>
                </div>
                <div class="kpi-card">
                  <h3>Net Profit</h3>
                  <p style="font-size: 24px; font-weight: bold; color: ${report.netProfit >= 0 ? '#16a34a' : '#dc2626'};">
                    ${formatCurrency(report.netProfit, currency)}
                  </p>
                </div>
                <div class="kpi-card">
                  <h3>Profit Margin</h3>
                  <p style="font-size: 24px; font-weight: bold;">
                    ${report.profitMargin.toFixed(1)}%
                  </p>
                </div>
              </div>
            </div>

            <script>
              window.onload = function() {
                setTimeout(function() {
                  window.print();
                }, 1000);
              };
            </script>
          </body>
          </html>
        `);
        
        reportWindow.document.close();
      }
      return;
    }

    // Excel format
    let csvContent = "data:text/csv;charset=utf-8,";
    
    csvContent += `${currency} FLEET PERFORMANCE REPORT\n`;
    csvContent += `Generated on,${formatDateTime(new Date())}\n`;
    csvContent += `Currency,${currency}\n`;
    csvContent += "\n";
    
    csvContent += "FLEET SUMMARY\n";
    csvContent += `Total Trips,${report.totalTrips}\n`;
    csvContent += `Active Trips,${report.activeTrips}\n`;
    csvContent += `Completed Trips,${report.completedTrips}\n`;
    csvContent += `Total Revenue,${report.totalRevenue}\n`;
    csvContent += `Total Expenses,${report.totalExpenses}\n`;
    csvContent += `Net Profit,${report.netProfit}\n`;
    csvContent += `Profit Margin (%),${report.profitMargin.toFixed(2)}\n`;
    csvContent += `Average Revenue per Trip,${report.avgRevenuePerTrip.toFixed(2)}\n`;
    csvContent += `Average Cost per Trip,${report.avgCostPerTrip.toFixed(2)}\n`;
    csvContent += "\n";

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `${currency.toLowerCase()}-fleet-report-${formatDate(new Date()).replace(/\s/g, '-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    alert(`${currency} fleet report downloaded successfully!`);
  } catch (error) {
    console.error(`Error generating ${currency} fleet report:`, error);
    alert(`Error generating ${currency} fleet report. Please try again.`);
  }
};