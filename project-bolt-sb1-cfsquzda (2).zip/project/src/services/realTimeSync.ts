// Real-time synchronization service
import { SyncEvent, AppVersion } from '../types';

class RealTimeSyncService {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private currentVersion = '1.0.0';
  private listeners: Map<string, Function[]> = new Map();

  constructor() {
    this.initializeConnection();
    this.checkAppVersion();
  }

  private initializeConnection() {
    try {
      // In production, this would connect to your WebSocket server
      // For demo purposes, we'll simulate the connection
      console.log('Initializing real-time sync connection...');
      
      // Simulate WebSocket connection
      this.simulateWebSocketConnection();
      
    } catch (error) {
      console.error('Failed to initialize real-time sync:', error);
      this.scheduleReconnect();
    }
  }

  private simulateWebSocketConnection() {
    // Simulate WebSocket events for demo
    setInterval(() => {
      this.broadcastEvent({
        id: `sync-${Date.now()}`,
        type: 'system_update',
        entityId: 'system',
        entityType: 'trip',
        action: 'update',
        data: { timestamp: new Date().toISOString() },
        timestamp: new Date().toISOString(),
        userId: 'system',
        version: 1
      });
    }, 30000); // Broadcast every 30 seconds
  }

  private scheduleReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      setTimeout(() => {
        this.reconnectAttempts++;
        this.initializeConnection();
      }, this.reconnectDelay * Math.pow(2, this.reconnectAttempts));
    }
  }

  private async checkAppVersion() {
    try {
      // In production, this would check against your deployment API
      const response = await fetch('/api/version');
      if (response.ok) {
        const versionInfo: AppVersion = await response.json();
        if (versionInfo.version !== this.currentVersion || versionInfo.forceReload) {
          this.handleVersionUpdate(versionInfo);
        }
      }
    } catch (error) {
      console.log('Version check failed (expected in demo):', error);
    }
    
    // Check version every 5 minutes
    setTimeout(() => this.checkAppVersion(), 5 * 60 * 1000);
  }

  private handleVersionUpdate(versionInfo: AppVersion) {
    const shouldReload = confirm(
      `A new version (${versionInfo.version}) is available!\n\n` +
      `New features:\n${versionInfo.features.join('\n')}\n\n` +
      `Would you like to reload the application now?`
    );

    if (shouldReload || versionInfo.forceReload) {
      window.location.reload();
    }
  }

  public broadcastEvent(event: SyncEvent) {
    // Broadcast to all connected clients
    const listeners = this.listeners.get(event.type) || [];
    listeners.forEach(listener => {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in sync event listener:', error);
      }
    });

    // Also broadcast to general listeners
    const generalListeners = this.listeners.get('*') || [];
    generalListeners.forEach(listener => {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in general sync event listener:', error);
      }
    });
  }

  public subscribe(eventType: string, listener: Function) {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    this.listeners.get(eventType)!.push(listener);

    // Return unsubscribe function
    return () => {
      const listeners = this.listeners.get(eventType);
      if (listeners) {
        const index = listeners.indexOf(listener);
        if (index > -1) {
          listeners.splice(index, 1);
        }
      }
    };
  }

  public publishTripUpdate(tripId: string, data: any) {
    this.broadcastEvent({
      id: `trip-${tripId}-${Date.now()}`,
      type: 'trip_update',
      entityId: tripId,
      entityType: 'trip',
      action: 'update',
      data,
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      version: 1
    });
  }

  public publishCostUpdate(costId: string, data: any) {
    this.broadcastEvent({
      id: `cost-${costId}-${Date.now()}`,
      type: 'cost_update',
      entityId: costId,
      entityType: 'cost',
      action: 'update',
      data,
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      version: 1
    });
  }

  public publishInvoiceUpdate(invoiceId: string, data: any) {
    this.broadcastEvent({
      id: `invoice-${invoiceId}-${Date.now()}`,
      type: 'invoice_update',
      entityId: invoiceId,
      entityType: 'invoice',
      action: 'update',
      data,
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      version: 1
    });
  }

  public publishPaymentUpdate(paymentId: string, data: any) {
    this.broadcastEvent({
      id: `payment-${paymentId}-${Date.now()}`,
      type: 'payment_update',
      entityId: paymentId,
      entityType: 'payment',
      action: 'update',
      data,
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      version: 1
    });
  }

  public disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}

// Export singleton instance
export const realTimeSyncService = new RealTimeSyncService();