import React, { useState, useEffect } from 'react';
import { AppProvider, useAppContext } from './context/AppContext';
import { realTimeSyncService } from './services/realTimeSync';
import Header from './components/layout/Header';
import Dashboard from './components/dashboard/Dashboard';
import YearToDateKPIs from './components/dashboard/YearToDateKPIs';
import ActiveTrips from './components/trips/ActiveTrips';
import CompletedTrips from './components/trips/CompletedTrips';
import FlagsInvestigations from './components/flags/FlagsInvestigations';
import CurrencyFleetReport from './components/reports/CurrencyFleetReport';
import InvoiceAgingDashboard from './components/invoicing/InvoiceAgingDashboard';
import CustomerRetentionDashboard from './components/performance/CustomerRetentionDashboard';
import MissedLoadsTracker from './components/trips/MissedLoadsTracker';
import TripDetails from './components/trips/TripDetails';
import TripForm from './components/trips/TripForm';
import SystemCostConfiguration from './components/admin/SystemCostConfiguration';
import Modal from './components/ui/Modal';
import { Trip, SystemCostRates, DEFAULT_SYSTEM_COST_RATES } from './types';

const AppContent: React.FC = () => {
  const { trips, addTrip, updateTrip, deleteTrip, missedLoads, addMissedLoad, updateMissedLoad } = useAppContext();
  const [currentView, setCurrentView] = useState('ytd-kpis');
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [showTripForm, setShowTripForm] = useState(false);
  const [editingTrip, setEditingTrip] = useState<Trip | undefined>();
  const [showSystemCostConfig, setShowSystemCostConfig] = useState(false);
  const [systemCostRates, setSystemCostRates] = useState<Record<'USD' | 'ZAR', SystemCostRates>>(DEFAULT_SYSTEM_COST_RATES);

  // Real-time sync setup
  useEffect(() => {
    const unsubscribe = realTimeSyncService.subscribe('*', (event) => {
      console.log('Received sync event:', event);
      // Handle real-time updates here
      // In a real app, you'd update the local state based on the event
    });

    return unsubscribe;
  }, []);

  const handleAddTrip = (tripData: Omit<Trip, 'id' | 'costs' | 'status'>) => {
    const tripId = addTrip(tripData);
    setShowTripForm(false);
    
    // Broadcast real-time update
    realTimeSyncService.publishTripUpdate(tripId, { action: 'created', tripData });
    
    const newTrip = trips.find(t => t.id === tripId);
    if (newTrip) {
      setSelectedTrip(newTrip);
    }
  };

  const handleUpdateTrip = (tripData: Omit<Trip, 'id' | 'costs' | 'status'>) => {
    if (editingTrip) {
      const updatedTrip = {
        ...editingTrip,
        ...tripData
      };
      updateTrip(updatedTrip);
      
      // Broadcast real-time update
      realTimeSyncService.publishTripUpdate(editingTrip.id, { action: 'updated', tripData: updatedTrip });
      
      setEditingTrip(undefined);
      setShowTripForm(false);
    }
  };

  const handleEditTrip = (trip: Trip) => {
    setEditingTrip(trip);
    setShowTripForm(true);
  };

  const handleDeleteTrip = (id: string) => {
    const trip = trips.find(t => t.id === id);
    const confirmMessage = `Are you sure you want to delete this trip?\n\n` +
      `Fleet: ${trip?.fleetNumber}\n` +
      `Driver: ${trip?.driverName}\n` +
      `Route: ${trip?.route}\n` +
      `Client: ${trip?.clientName} (${trip?.clientType === 'internal' ? 'Internal' : 'External'})\n\n` +
      `This will permanently delete:\n` +
      `• All ${trip?.costs.length || 0} cost entries\n` +
      `• All attached documents\n` +
      `• All investigation records\n\n` +
      `This action cannot be undone.`;

    if (confirm(confirmMessage)) {
      deleteTrip(id);
      
      // Broadcast real-time update
      realTimeSyncService.publishTripUpdate(id, { action: 'deleted' });
      
      if (selectedTrip && selectedTrip.id === id) {
        setSelectedTrip(null);
      }
    }
  };

  const handleViewTrip = (trip: Trip) => {
    setSelectedTrip(trip);
  };

  const handleFollowUp = (tripId: string) => {
    // Navigate to trip details or open follow-up modal
    const trip = trips.find(t => t.id === tripId);
    if (trip) {
      setSelectedTrip(trip);
    }
  };

  const closeTripForm = () => {
    setShowTripForm(false);
    setEditingTrip(undefined);
  };

  const handleNewTrip = () => {
    setShowTripForm(true);
  };

  const handleUpdateSystemCostRates = (currency: 'USD' | 'ZAR', rates: SystemCostRates) => {
    setSystemCostRates(prev => ({
      ...prev,
      [currency]: rates
    }));
  };

  const renderContent = () => {
    if (selectedTrip) {
      return (
        <TripDetails
          trip={selectedTrip}
          onBack={() => setSelectedTrip(null)}
        />
      );
    }

    switch (currentView) {
      case 'ytd-kpis':
        return <YearToDateKPIs trips={trips} />;
      case 'dashboard':
        return <Dashboard trips={trips} />;
      case 'active-trips':
        return (
          <ActiveTrips
            trips={trips.filter(trip => trip.status === 'active')}
            onEdit={handleEditTrip}
            onDelete={handleDeleteTrip}
            onView={handleViewTrip}
          />
        );
      case 'completed-trips':
        return (
          <CompletedTrips
            trips={trips.filter(trip => trip.status === 'completed' || trip.status === 'invoiced' || trip.status === 'paid')}
            onView={handleViewTrip}
          />
        );
      case 'flags':
        return <FlagsInvestigations trips={trips} />;
      case 'reports':
        return <CurrencyFleetReport trips={trips} />;
      case 'system-costs':
        return (
          <SystemCostConfiguration
            currentRates={systemCostRates}
            onUpdateRates={handleUpdateSystemCostRates}
            userRole="admin"
          />
        );
      case 'invoice-aging':
        return (
          <InvoiceAgingDashboard
            trips={trips}
            onFollowUp={handleFollowUp}
            onViewTrip={handleViewTrip}
          />
        );
      case 'customer-retention':
        return <CustomerRetentionDashboard trips={trips} />;
      case 'missed-loads':
        return (
          <MissedLoadsTracker
            missedLoads={missedLoads}
            onAddMissedLoad={addMissedLoad}
            onUpdateMissedLoad={updateMissedLoad}
          />
        );
      default:
        return <YearToDateKPIs trips={trips} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        currentView={currentView}
        onNavigate={setCurrentView}
        onNewTrip={handleNewTrip}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>

      <Modal
        isOpen={showTripForm}
        onClose={closeTripForm}
        title={editingTrip ? 'Edit Trip' : 'Create New Trip'}
        maxWidth="lg"
      >
        <TripForm
          trip={editingTrip}
          onSubmit={editingTrip ? handleUpdateTrip : handleAddTrip}
          onCancel={closeTripForm}
        />
      </Modal>
    </div>
  );
};

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;